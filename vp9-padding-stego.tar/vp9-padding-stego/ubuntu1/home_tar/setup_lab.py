#!/usr/bin/env python3
from __future__ import annotations

import zlib
from pathlib import Path

from tools.vp9_pad import MARKER, build_ivf, insert_message


ROOT = Path(__file__).resolve().parent
CHALLENGES = ROOT / "challenges"
ANSWERS = ROOT / "answers"


def main() -> None:
    CHALLENGES.mkdir(exist_ok=True)
    ANSWERS.mkdir(exist_ok=True)

    clean = CHALLENGES / "clean.ivf"
    suspicious = CHALLENGES / "suspicious.ivf"
    message = "FLAG{HELLO_PTIT}"

    build_ivf(clean)
    insert_message(clean, suspicious, message.encode("utf-8"), frame_index=2)

    print("Lab initialized")
    print(f"Created: {clean}")
    print(f"Created: {suspicious}")
    print("Default hidden message: FLAG{HELLO_PTIT}")
    print("Suspicious frame: 2")


if __name__ == "__main__":
    main()
