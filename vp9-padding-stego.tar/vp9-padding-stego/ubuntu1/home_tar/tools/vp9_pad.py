#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import struct
import sys
import zlib
from dataclasses import dataclass
from pathlib import Path


MARKER = b"PTITPAD1"
IVF_HEADER = struct.Struct("<4sHH4sHHIIII")
FRAME_HEADER = struct.Struct("<IQ")
WIDTH = 160
HEIGHT = 90
FRAME_COUNT = 4


@dataclass
class Frame:
    index: int
    header_offset: int
    payload_offset: int
    size: int
    timestamp: int
    payload: bytes


def deterministic_payload(index: int, size: int) -> bytes:
    seed = b"VP9-FRAME-%02d|" % index
    out = bytearray()
    counter = 0
    while len(out) < size:
        block = seed + bytes([(counter * 17 + index * 31) % 256])
        out.extend(block)
        counter += 1
    # Avoid accidental marker matches in generated clean frames.
    return bytes(out[:size]).replace(MARKER, b"PTITPAD?")


def build_ivf(path: Path) -> None:
    """Create a deterministic teaching IVF file with VP90 codec tag."""
    sizes = [88, 91, 94, 89]
    frames = [deterministic_payload(i, size) for i, size in enumerate(sizes)]
    header = IVF_HEADER.pack(
        b"DKIF", 0, 32, b"VP90", WIDTH, HEIGHT, 1, 30, len(frames), 0
    )
    data = bytearray(header)
    for i, payload in enumerate(frames):
        data.extend(FRAME_HEADER.pack(len(payload), i))
        data.extend(payload)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def read_ivf(path: Path) -> tuple[dict, list[Frame]]:
    data = path.read_bytes()
    if len(data) < IVF_HEADER.size:
        raise ValueError("File too small for IVF header")
    magic, version, header_size, codec, width, height, den, num, frame_count, unused = IVF_HEADER.unpack_from(data, 0)
    if magic != b"DKIF":
        raise ValueError("Not an IVF file: magic bytes are not DKIF")
    if header_size != 32:
        raise ValueError(f"Unsupported IVF header size: {header_size}")

    pos = header_size
    frames: list[Frame] = []
    index = 0
    while pos + FRAME_HEADER.size <= len(data):
        frame_size, timestamp = FRAME_HEADER.unpack_from(data, pos)
        payload_offset = pos + FRAME_HEADER.size
        end = payload_offset + frame_size
        if end > len(data):
            raise ValueError(f"Frame {index} exceeds file length")
        frames.append(Frame(index, pos, payload_offset, frame_size, timestamp, data[payload_offset:end]))
        pos = end
        index += 1

    info = {
        "magic": magic.decode("ascii", "replace"),
        "version": version,
        "header_size": header_size,
        "codec": codec.decode("ascii", "replace"),
        "width": width,
        "height": height,
        "timebase": f"{den}/{num}",
        "declared_frame_count": frame_count,
        "parsed_frame_count": len(frames),
    }
    return info, frames


def make_envelope(message: bytes) -> bytes:
    crc = zlib.crc32(message) & 0xFFFFFFFF
    envelope = MARKER + struct.pack("<HI", len(message), crc) + message
    if len(envelope) < 48:
        envelope += b"\x00" * (48 - len(envelope))
    return envelope


def parse_envelope(payload: bytes, marker_offset: int) -> dict:
    pos = marker_offset
    if payload[pos:pos + len(MARKER)] != MARKER:
        raise ValueError("Marker not found at requested offset")
    meta = pos + len(MARKER)
    msg_len, expected_crc = struct.unpack_from("<HI", payload, meta)
    msg_start = meta + 6
    msg_end = msg_start + msg_len
    message = payload[msg_start:msg_end]
    actual_crc = zlib.crc32(message) & 0xFFFFFFFF
    next_marker = payload.find(MARKER, pos + 1)
    if next_marker == -1:
        envelope_len = len(payload) - pos
    else:
        envelope_len = next_marker - pos
    return {
        "marker_offset": marker_offset,
        "message_length": envelope_len,
        "message_bytes": msg_len,
        "crc32_ok": actual_crc == expected_crc,
        "message": message.decode("utf-8", "replace"),
    }


def write_ivf(path: Path, info: dict, frames: list[Frame]) -> None:
    header = IVF_HEADER.pack(
        b"DKIF", 0, 32, b"VP90",
        int(info.get("width", WIDTH)),
        int(info.get("height", HEIGHT)),
        1, 30, len(frames), 0,
    )
    data = bytearray(header)
    for frame in frames:
        data.extend(FRAME_HEADER.pack(len(frame.payload), frame.timestamp))
        data.extend(frame.payload)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def insert_message(infile: Path, outfile: Path, message: bytes, frame_index: int) -> None:
    info, frames = read_ivf(infile)
    if frame_index < 0 or frame_index >= len(frames):
        raise ValueError(f"Frame index out of range: {frame_index}")
    envelope = make_envelope(message)
    target = frames[frame_index]
    frames[frame_index] = Frame(
        target.index,
        target.header_offset,
        target.payload_offset,
        target.size + len(envelope),
        target.timestamp,
        target.payload + envelope,
    )
    write_ivf(outfile, info, frames)


def command_info(args: argparse.Namespace) -> int:
    info, frames = read_ivf(Path(args.ivf))
    print(f"Magic bytes: {info['magic']}")
    print(f"Codec: {info['codec']}")
    print(f"Size: {info['width']}x{info['height']}")
    print(f"Timebase: {info['timebase']}")
    print(f"Declared frames: {info['declared_frame_count']}")
    print(f"Parsed frames: {info['parsed_frame_count']}")
    for frame in frames:
        print(
            f"frame {frame.index}: offset={frame.header_offset} "
            f"payload_offset={frame.payload_offset} size={frame.size} timestamp={frame.timestamp}"
        )
    return 0


def scan_file(path: Path) -> list[dict]:
    _info, frames = read_ivf(path)
    results = []
    for frame in frames:
        marker_offset = frame.payload.find(MARKER)
        if marker_offset == -1:
            results.append({"frame": frame.index, "status": "ok", "size": frame.size})
            continue
        parsed = parse_envelope(frame.payload, marker_offset)
        parsed.update({"frame": frame.index, "status": "SUSPICIOUS", "size": frame.size})
        results.append(parsed)
    return results


def command_scan(args: argparse.Namespace) -> int:
    results = scan_file(Path(args.ivf))
    if args.json:
        public = []
        for item in results:
            public.append({k: v for k, v in item.items() if k != "message"})
        print(json.dumps(public, indent=2))
        return 0

    for item in results:
        if item["status"] == "ok":
            print(f"frame {item['frame']}: ok")
        else:
            print(
                f"frame {item['frame']}: SUSPICIOUS "
                f"marker_offset={item['marker_offset']} "
                f"message_length={item['message_length']} "
                f"crc32_ok={item['crc32_ok']}"
            )
    return 0


def command_extract(args: argparse.Namespace) -> int:
    results = scan_file(Path(args.ivf))
    for item in results:
        if item["status"] == "SUSPICIOUS":
            out = Path(args.out)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(item["message"] + "\n", encoding="utf-8")
            print(f"Extracted frame: {item['frame']}")
            print(f"Recovered message: {item['message']}")
            print(f"Wrote: {out}")
            return 0
    print("No hidden message found", file=sys.stderr)
    return 1


def command_insert(args: argparse.Namespace) -> int:
    message = Path(args.message_file).read_bytes().rstrip(b"\r\n")
    insert_message(Path(args.input_ivf), Path(args.output_ivf), message, args.frame)
    print(f"Inserted message into frame {args.frame}")
    print(f"Output: {args.output_ivf}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Inspect VP9 IVF padding/trailing data")
    sub = parser.add_subparsers(dest="command", required=True)

    p_info = sub.add_parser("info", help="print IVF metadata and frame offsets")
    p_info.add_argument("ivf")
    p_info.set_defaults(func=command_info)

    p_scan = sub.add_parser("scan", help="scan frames for appended padding marker")
    p_scan.add_argument("ivf")
    p_scan.add_argument("--json", action="store_true")
    p_scan.set_defaults(func=command_scan)

    p_extract = sub.add_parser("extract", help="extract hidden message")
    p_extract.add_argument("ivf")
    p_extract.add_argument("--out", required=True)
    p_extract.set_defaults(func=command_extract)

    p_insert = sub.add_parser("insert", help="append marker and message to a frame")
    p_insert.add_argument("input_ivf")
    p_insert.add_argument("message_file")
    p_insert.add_argument("output_ivf")
    p_insert.add_argument("--frame", type=int, default=2)
    p_insert.set_defaults(func=command_insert)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
