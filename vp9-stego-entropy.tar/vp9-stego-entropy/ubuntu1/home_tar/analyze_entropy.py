from __future__ import annotations

import argparse

from vp9_entropy_tools import candidate_positions, is_probable_vp9_frame, list_video_simpleblocks, load_bytes


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect VP9 entropy-coded payload windows used for the lab.")
    parser.add_argument("input", nargs="?", default="input.webm")
    parser.add_argument("--stride", type=int, default=23)
    parser.add_argument("--group-size", type=int, default=160)
    parser.add_argument("--tail-ratio", type=float, default=0.60)
    parser.add_argument("--preview", type=int, default=10)
    args = parser.parse_args()

    data = load_bytes(args.input)
    blocks = list_video_simpleblocks(data)
    inter_blocks = [
        block for block in blocks
        if not block.is_keyframe_flag
        and is_probable_vp9_frame(data[block.payload_offset:block.payload_offset + block.payload_size])
    ]
    candidates = candidate_positions(data, stride=args.stride, tail_ratio=args.tail_ratio)
    raw_candidate_bits = len(candidates)
    capacity_bits = raw_candidate_bits // args.group_size
    usable_bytes = max((capacity_bits - 16) // 8, 0)

    print(f"Video SimpleBlocks: {len(blocks)}")
    print(f"Probable VP9 interframes: {len(inter_blocks)}")
    print(f"Entropy-payload candidate bytes: {raw_candidate_bits}")
    print(f"Parity-coded payload capacity: {capacity_bits} bits")
    print(f"Usable payload after 16-bit length prefix: {usable_bytes} bytes")
    print(f"Tail-frame start ratio: {args.tail_ratio:.2f}")
    print("Heuristic: skip frame headers, use tail non-key VP9 payload bytes, and encode one bit per parity group.")
    print("Preview of candidate locations:")
    for ref in candidates[: args.preview]:
        print(
            f"  block={ref.block_index:03d} payload_offset={ref.relative_payload_offset:04d} "
            f"byte=0x{data[ref.absolute_offset]:02x} lsb={data[ref.absolute_offset] & 1}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
