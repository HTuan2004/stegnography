from __future__ import annotations

import argparse
import subprocess
import tempfile
from pathlib import Path

from vp9_entropy_tools import candidate_positions, encode_message_bits, load_bytes, save_bytes


DEFAULT_MESSAGE = "VP9!"


def main() -> int:
    parser = argparse.ArgumentParser(description="Hide a message with parity-coded LSBs in VP9 entropy payload bytes.")
    parser.add_argument("--input", default="input.webm")
    parser.add_argument("--output", default="stego.webm")
    parser.add_argument("--message", default=DEFAULT_MESSAGE)
    parser.add_argument("--stride", type=int, default=23)
    parser.add_argument("--group-size", type=int, default=160)
    parser.add_argument("--tail-ratio", type=float, default=0.60)
    parser.add_argument("--no-validate", action="store_true", help="skip per-change decoder validation")
    args = parser.parse_args()

    data = load_bytes(args.input)
    refs = candidate_positions(data, stride=args.stride, tail_ratio=args.tail_ratio)
    bits = encode_message_bits(args.message)
    capacity_bits = len(refs) // args.group_size
    if len(bits) > capacity_bits:
        raise SystemExit(
            f"Message is too large. Need {len(bits)} parity groups but only found {capacity_bits}."
        )

    def parity(group):
        value = 0
        for ref in group:
            value ^= data[ref.absolute_offset] & 1
        return value

    def decoder_accepts(candidate_data: bytearray) -> bool:
        if args.no_validate:
            return True
        with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as tmp:
            tmp_path = Path(tmp.name)
            tmp.write(candidate_data)
        try:
            result = subprocess.run(
                ["ffmpeg", "-v", "error", "-i", str(tmp_path), "-map", "0:v:0", "-f", "null", "-"],
                capture_output=True,
                text=True,
            )
            return result.returncode == 0
        finally:
            tmp_path.unlink(missing_ok=True)

    changed = 0
    validated_trials = 0
    for bit_index, bit in enumerate(bits):
        desired = int(bit)
        start = bit_index * args.group_size
        group = refs[start:start + args.group_size]
        if parity(group) == desired:
            continue

        committed = False
        for ref in group:
            trial = bytearray(data)
            trial[ref.absolute_offset] ^= 1
            validated_trials += 1
            if decoder_accepts(trial):
                data = trial
                changed += 1
                committed = True
                break
        if not committed:
            raise SystemExit(f"No decoder-safe LSB flip found for parity group {bit_index}.")

    save_bytes(args.output, data)
    print("Entropy embedding complete")
    print(f"Message bytes: {len(args.message.encode('utf-8'))}")
    print(f"Bits embedded: {len(bits)} parity groups")
    print(f"Changed low-significance payload bits: {changed}")
    print(f"Candidate bytes available: {len(refs)}")
    print(f"Decoder-validated trials: {validated_trials}")
    print(f"Output file: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
