from __future__ import annotations

import argparse

from vp9_entropy_tools import candidate_positions, decode_message_bits, load_bytes


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract a message from VP9 entropy payload LSBs.")
    parser.add_argument("--input", default="stego.webm")
    parser.add_argument("--stride", type=int, default=23)
    parser.add_argument("--group-size", type=int, default=160)
    parser.add_argument("--tail-ratio", type=float, default=0.60)
    args = parser.parse_args()

    data = load_bytes(args.input)
    refs = candidate_positions(data, stride=args.stride, tail_ratio=args.tail_ratio)
    group_count = len(refs) // args.group_size
    bits = []
    for group_index in range(group_count):
        value = 0
        group = refs[group_index * args.group_size:(group_index + 1) * args.group_size]
        for ref in group:
            value ^= data[ref.absolute_offset] & 1
        bits.append(str(value))
    bitstream = "".join(bits)
    message = decode_message_bits(bitstream)
    print(f"Recovered message: {message}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
