from __future__ import annotations

import argparse

from vp9_entropy_tools import candidate_positions, load_bytes


def main() -> int:
    parser = argparse.ArgumentParser(description="Show low-significance bit differences in selected VP9 payload bytes.")
    parser.add_argument("original", nargs="?", default="input.webm")
    parser.add_argument("stego", nargs="?", default="stego.webm")
    parser.add_argument("--stride", type=int, default=23)
    parser.add_argument("--tail-ratio", type=float, default=0.60)
    parser.add_argument("--limit", type=int, default=16)
    args = parser.parse_args()

    original = load_bytes(args.original)
    stego = load_bytes(args.stego)
    refs = candidate_positions(original, stride=args.stride, tail_ratio=args.tail_ratio)

    print("Changed low-significance payload bits")
    print(" idx | block | payload_off | original | stego")
    print("-----+-------+-------------+----------+------")
    shown = 0
    for idx, ref in enumerate(refs):
        o_bit = original[ref.absolute_offset] & 1
        s_bit = stego[ref.absolute_offset] & 1
        if o_bit == s_bit:
            continue
        print(
            f"{idx:4d} | {ref.block_index:5d} | {ref.relative_payload_offset:11d} |"
            f"    {o_bit}     |   {s_bit}"
        )
        shown += 1
        if shown >= args.limit:
            break
    if shown == 0:
        print("No changed LSBs were found in the inspected candidate range.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
