from __future__ import annotations

import argparse
import re
import subprocess


def run_ffmpeg(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, capture_output=True, text=True)


def decoder_check(path: str) -> bool:
    result = run_ffmpeg(["ffmpeg", "-v", "error", "-i", path, "-map", "0:v:0", "-f", "null", "-"])
    if result.returncode != 0:
        print("Decoder check: FAILED")
        if result.stderr.strip():
            print(result.stderr.strip())
        return False
    print("Decoder check: OK")
    return True


def psnr(original: str, stego: str) -> float:
    result = run_ffmpeg(["ffmpeg", "-i", original, "-i", stego, "-lavfi", "psnr", "-f", "null", "-"])
    text = result.stderr + result.stdout
    match = re.search(r"average:([0-9.]+)", text)
    if result.returncode != 0 or match is None:
        raise RuntimeError(text.strip() or "ffmpeg psnr failed")
    return float(match.group(1))


def ssim(original: str, stego: str) -> float:
    result = run_ffmpeg(["ffmpeg", "-i", original, "-i", stego, "-lavfi", "ssim", "-f", "null", "-"])
    text = result.stderr + result.stdout
    match = re.search(r"All:([0-9.]+)", text)
    if result.returncode != 0 or match is None:
        raise RuntimeError(text.strip() or "ffmpeg ssim failed")
    return float(match.group(1))


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify decode safety and visual quality of the stego VP9/WebM file.")
    parser.add_argument("original", nargs="?", default="input.webm")
    parser.add_argument("stego", nargs="?", default="stego.webm")
    parser.add_argument("--min-psnr", type=float, default=35.0)
    parser.add_argument("--min-ssim", type=float, default=0.94)
    args = parser.parse_args()

    if not decoder_check(args.stego):
        return 1

    avg_psnr = psnr(args.original, args.stego)
    all_ssim = ssim(args.original, args.stego)
    print(f"PSNR average: {avg_psnr:.2f} dB")
    print(f"SSIM all: {all_ssim:.6f}")
    if avg_psnr < args.min_psnr or all_ssim < args.min_ssim:
        print("Quality check: FAILED")
        return 1
    print("Quality check: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
