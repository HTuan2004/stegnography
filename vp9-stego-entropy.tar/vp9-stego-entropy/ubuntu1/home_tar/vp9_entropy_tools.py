from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


MASTER_IDS = {
    0x18538067,  # Segment
    0x1549A966,  # Info
    0x1654AE6B,  # Tracks
    0xAE,        # TrackEntry
    0x1F43B675,  # Cluster
    0x114D9B74,  # SeekHead
    0x4DBB,      # Seek
    0x1043A770,  # Chapters
    0x45B9,      # EditionEntry
    0xB6,        # ChapterAtom
    0x1254C367,  # Tags
    0x7373,      # Tag
    0x63C0,      # Targets
    0x67C8,      # SimpleTag
    0x1C53BB6B,  # Cues
    0xBB,        # CuePoint
    0xB7,        # CueTrackPositions
    0xA0,        # BlockGroup
}


@dataclass(frozen=True)
class SimpleBlockRef:
    index: int
    track_number: int
    element_offset: int
    data_offset: int
    size: int
    flags_offset: int
    flags: int
    payload_offset: int
    payload_size: int

    @property
    def is_keyframe_flag(self) -> bool:
        return bool(self.flags & 0x80)


@dataclass(frozen=True)
class CandidateRef:
    block_index: int
    absolute_offset: int
    relative_payload_offset: int
    payload_size: int


def load_bytes(path: str | Path) -> bytearray:
    return bytearray(Path(path).read_bytes())


def save_bytes(path: str | Path, data: bytearray) -> None:
    Path(path).write_bytes(data)


def vint_length(first_byte: int) -> int:
    mask = 0x80
    for length in range(1, 9):
        if first_byte & mask:
            return length
        mask >>= 1
    raise ValueError("invalid EBML variable-length integer")


def read_id(data: bytearray, offset: int) -> tuple[int, int]:
    length = vint_length(data[offset])
    return int.from_bytes(data[offset:offset + length], "big"), length


def read_size(data: bytearray, offset: int) -> tuple[int, int, bool]:
    length = vint_length(data[offset])
    raw = int.from_bytes(data[offset:offset + length], "big")
    marker = 1 << (7 * length)
    value = raw - marker
    unknown = value == (marker - 1)
    return value, length, unknown


def iter_children(data: bytearray, start: int, end: int):
    cursor = start
    while cursor < end:
        element_id, id_len = read_id(data, cursor)
        size, size_len, unknown = read_size(data, cursor + id_len)
        data_offset = cursor + id_len + size_len
        element_end = end if unknown else data_offset + size
        yield {
            "id": element_id,
            "offset": cursor,
            "id_len": id_len,
            "size_len": size_len,
            "data_offset": data_offset,
            "size": size,
            "end": element_end,
            "unknown_size": unknown,
        }
        cursor = element_end


def read_unsigned(data: bytearray, start: int, size: int) -> int:
    return int.from_bytes(data[start:start + size], "big")


def read_track_number(block_data: bytearray, offset: int) -> tuple[int, int]:
    length = vint_length(block_data[offset])
    raw = int.from_bytes(block_data[offset:offset + length], "big")
    marker = 1 << (7 * length)
    return raw - marker, length


def _find_segment(data: bytearray) -> dict:
    for element in iter_children(data, 0, len(data)):
        if element["id"] == 0x18538067:
            return element
    raise ValueError("segment element not found")


def find_video_track_number(data: bytearray) -> int:
    segment = _find_segment(data)
    for element in iter_children(data, segment["data_offset"], segment["end"]):
        if element["id"] != 0x1654AE6B:
            continue
        for track_entry in iter_children(data, element["data_offset"], element["end"]):
            if track_entry["id"] != 0xAE:
                continue
            track_number = None
            track_type = None
            for field in iter_children(data, track_entry["data_offset"], track_entry["end"]):
                if field["id"] == 0xD7:
                    track_number = read_unsigned(data, field["data_offset"], field["size"])
                elif field["id"] == 0x83:
                    track_type = read_unsigned(data, field["data_offset"], field["size"])
            if track_number is not None and track_type == 1:
                return track_number
    raise ValueError("video track not found")


def list_video_simpleblocks(data: bytearray) -> list[SimpleBlockRef]:
    video_track = find_video_track_number(data)
    segment = _find_segment(data)
    blocks: list[SimpleBlockRef] = []
    block_index = 0

    for element in iter_children(data, segment["data_offset"], segment["end"]):
        if element["id"] != 0x1F43B675:
            continue
        for child in iter_children(data, element["data_offset"], element["end"]):
            if child["id"] != 0xA3:
                continue
            track_number, track_len = read_track_number(data, child["data_offset"])
            if track_number != video_track:
                continue
            flags_offset = child["data_offset"] + track_len + 2
            payload_offset = flags_offset + 1
            payload_size = child["data_offset"] + child["size"] - payload_offset
            blocks.append(
                SimpleBlockRef(
                    index=block_index,
                    track_number=track_number,
                    element_offset=child["offset"],
                    data_offset=child["data_offset"],
                    size=child["size"],
                    flags_offset=flags_offset,
                    flags=data[flags_offset],
                    payload_offset=payload_offset,
                    payload_size=payload_size,
                )
            )
            block_index += 1
    return blocks


def is_probable_vp9_frame(payload: bytes | bytearray) -> bool:
    return bool(payload) and (payload[0] & 0xC0) == 0x80


def is_probable_interframe(payload: bytes | bytearray) -> bool:
    return is_probable_vp9_frame(payload) and bool(payload[0] & 0x01)


def entropy_window(block: SimpleBlockRef) -> tuple[int, int]:
    # The VP9 uncompressed header and mode syntax live near the start of a frame.
    # This lab targets a conservative later window that is dominated by entropy-coded payload bytes.
    skip = max(32, min(160, block.payload_size // 3))
    end_margin = max(4, min(32, block.payload_size // 20))
    start = block.payload_offset + skip
    end = block.payload_offset + block.payload_size - end_margin
    if end <= start:
        return block.payload_offset, block.payload_offset
    return start, end


def candidate_positions(data: bytearray, stride: int = 23, tail_ratio: float = 0.60) -> list[CandidateRef]:
    blocks = list_video_simpleblocks(data)
    min_block_index = int(len(blocks) * tail_ratio)
    refs: list[CandidateRef] = []
    for block in blocks:
        payload = data[block.payload_offset:block.payload_offset + block.payload_size]
        if (
            block.index < min_block_index
            or block.payload_size < 96
            or block.is_keyframe_flag
            or not is_probable_vp9_frame(payload)
        ):
            continue
        start, end = entropy_window(block)
        for absolute in range(start, end, stride):
            refs.append(
                CandidateRef(
                    block_index=block.index,
                    absolute_offset=absolute,
                    relative_payload_offset=absolute - block.payload_offset,
                    payload_size=block.payload_size,
                )
            )
    return refs


def encode_message_bits(message: str) -> str:
    payload = message.encode("utf-8")
    if len(payload) > 0xFFFF:
        raise ValueError("message is too long")
    prefix = len(payload).to_bytes(2, "big")
    return "".join(f"{byte:08b}" for byte in prefix + payload)


def decode_message_bits(bits: str) -> str:
    if len(bits) < 16:
        raise ValueError("not enough bits for length prefix")
    size = int(bits[:16], 2)
    needed = 16 + size * 8
    if len(bits) < needed:
        raise ValueError("not enough bits for the advertised payload length")
    payload = bytes(int(bits[i:i + 8], 2) for i in range(16, needed, 8))
    return payload.decode("utf-8")
