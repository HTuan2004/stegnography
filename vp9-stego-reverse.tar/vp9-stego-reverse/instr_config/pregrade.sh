#!/bin/bash

dbg=/tmp/pregrade.log

STUDENT_HOME="$HOME"

cd "$STUDENT_HOME" || exit 0

if command -v sqlite3 >/dev/null 2>&1; then

    for fname in .mozilla/firefox/*default*/places.sqlite; do
        [ -f "$fname" ] || continue

        outpath="$STUDENT_HOME/.local/result"
        outfile="$outpath/moz_places.txt"

        mkdir -p "$outpath"

        sqlite3 "$fname" \
        "SELECT * FROM moz_places;" > "$outfile"
    done
fi

exit 0

